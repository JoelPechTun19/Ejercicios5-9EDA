import WordClassifier from './Clasificador.js';
import UI from './Interfaz.js';

const wordClassifier = new WordClassifier();

const ui = new UI(wordClassifier);
