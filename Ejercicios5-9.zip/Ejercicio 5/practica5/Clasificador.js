
export default class WordClassifier
{
    constructor()
    {
        this.wordLists = {};
    }

    classifyWord(word)
    {
        const firstLetter = word.charAt(0).toUpperCase();

        if (!this.wordLists[firstLetter])
        {
            this.wordLists[firstLetter] = [];
        }

        this.wordLists[firstLetter].push(word);
    }
}
