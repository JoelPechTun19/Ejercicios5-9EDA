export default class UI {
    constructor(wordClassifier) {
        this.wordClassifier = wordClassifier;
        this.initUI();
    }

    initUI() {
        const wordInput = document.getElementById('wordInput');
        const addWordBtn = document.getElementById('addWordBtn');
        const wordListsDiv = document.getElementById('wordLists');

        addWordBtn.addEventListener('click', () => {
            const word = wordInput.value.trim();

            // Validar que la entrada contenga solo letras mayúsculas o minúsculas
            if (/^[a-zA-Z]+$/.test(word)) {
                this.wordClassifier.classifyWord(word);
                wordInput.value = '';
                wordInput.focus();
                this.updateUI(wordListsDiv);
            } else {
                // Mostrar alerta si se ingresan números
                alert('Por favor, ingrese solo letras.');
            }
        });
    }

    updateUI(wordListsDiv) {
        wordListsDiv.innerHTML = '';

        // Ordenar las letras alfabéticamente para una mejor presentación
        const sortedLetters = Object.keys(this.wordClassifier.wordLists).sort();

        sortedLetters.forEach(letter => {
            const list = document.createElement('div');
            list.className = 'list';
            list.innerHTML = `<strong>Lista ${letter}:</strong> ${this.wordClassifier.wordLists[letter].join(', ')}`;
            wordListsDiv.appendChild(list);
        });
    }
}