import { Palabras } from "./palabras.js";

const palabras = new Palabras();
const palabraInput = document.getElementById('palabraInput');
const agregarPalabraBtn = document.getElementById('agregarPalabraBtn');
const palabrasLista = document.getElementById('palabraLista');

agregarPalabraBtn.addEventListener('click', () => {
    const palabra = palabraInput.value.trim();
    if(palabra) {
        palabras.agregarPalabra(palabra);
        actualizarListaPalabras();
        palabraInput.value = '';
    }
});

function actualizarListaPalabras() {
    palabrasLista.innerHTML = '';
    const listaDePalabras = palabras.obtenerLista();
    const letrasOrdenadas = [...listaDePalabras.keys()].sort();
    
    letrasOrdenadas.forEach((letra, index) => {
        const palabras = listaDePalabras.get(letra);
        const listaElementos = document.createElement('ul');
        listaElementos.innerHTML = `Lista${index + 1}: ${palabras.join(', ')}`;
        palabrasLista.appendChild(listaElementos);
    });
}
