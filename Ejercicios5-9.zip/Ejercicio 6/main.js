import { PalabraInvertida } from './PalabraInvertida.js';

let palabrasGuardadas = [];

document.getElementById('guardarButton').addEventListener('click', function () {
    const inputElement = document.getElementById('inputWord');
    const palabra = inputElement.value;

    // Utilizar una expresión regular para verificar si la palabra contiene solo letras.
    if (/^[a-zA-Z]+$/.test(palabra.trim())) {
        palabrasGuardadas.push(palabra);
        inputElement.value = '';
        alert(`"${palabra}" Guardado con Éxito`);
    } else {
        alert('Lo sentimos, solamente se permiten letras');
    }
});

document.getElementById('invertirButton').addEventListener('click', function () {
    const listaElement = document.getElementById('listaPalabras');
    listaElement.innerHTML = ''; // Limpiar la lista antes de agregar nuevas palabras invertidas.

    palabrasGuardadas.forEach(function (palabra) {
        const palabraInvertida = PalabraInvertida.invertir(palabra);
        const listItem = document.createElement('li');
        listItem.textContent = `${palabra}, Invertida: ${palabraInvertida}`;
        listaElement.appendChild(listItem);
    });
});
