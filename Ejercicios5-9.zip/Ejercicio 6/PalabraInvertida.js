export class PalabraInvertida {
    static invertir(palabra) {
        return palabra.split('').reverse().join('');
    }
}
