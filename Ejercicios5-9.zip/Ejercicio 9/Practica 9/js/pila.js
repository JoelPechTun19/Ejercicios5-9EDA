export default class Pila {
    constructor() {
        this.valores = [];
    }

    agregarValor(valor) {
        this.valores.push(valor);
    }

    eliminarValor() {
        return this.valores.pop();
    }

    pilaEstaVacia() {
        return this.valores.length === 0;
    }

    obtenerElementos() {
        return [...this.valores];
    }
    remplazar(valorNuevo, valorViejo) {
        const pilaTemporal = [];

        while(!this.pilaEstaVacia()) {
            const valor = this.eliminarValor();
            if(valor === valorViejo) {
                pilaTemporal.push(valorNuevo);
            } else {
                pilaTemporal.push(valor);
            }
        }

        while(pilaTemporal.length > 0) {
            this.agregarValor(pilaTemporal.pop());
        }
    }
}