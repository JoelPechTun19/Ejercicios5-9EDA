import Pila from "./pila.js";

const verificarBtn = document.getElementById('verificarBtn');
const valorViejoInput = document.getElementById('valorViejo');
const valorNuevoInput = document.getElementById('valorNuevo');
const listaCompleta = document.getElementById('listaCompleta');
const mostrarValores = document.getElementById('mostrarValores');

const pila = new Pila();
pila.agregarValor(3);
pila.agregarValor(4);
pila.agregarValor(7);
pila.agregarValor(4);
pila.agregarValor(7);
pila.agregarValor(2);
pila.agregarValor(1);
pila.agregarValor(8);

verificarBtn.addEventListener('click', () => {
    const valorNuevo = parseInt(valorNuevoInput.value);
    const valorViejo = parseInt(valorViejoInput.value);
    
    const pilaTemporal = new Pila();

    while(!pila.pilaEstaVacia()) {
        const valor = pila.eliminarValor();
        if(valor === valorViejo) {
            pilaTemporal.agregarValor(valorNuevo);
        } else {
            pilaTemporal.agregarValor(valor);
        }
    }
    while(!pilaTemporal.pilaEstaVacia()) {
        pila.agregarValor(pilaTemporal.eliminarValor());
    }

    mostrarValores.innerHTML = `Nuevos valores de la pila: ${pila.obtenerElementos().join(', ')}`;
});

function mostrarListas() {
    const valores = pila.obtenerElementos();
    listaCompleta.innerHTML = `Valores de la pila: ${valores.join(', ')}`;
}

mostrarListas(); 