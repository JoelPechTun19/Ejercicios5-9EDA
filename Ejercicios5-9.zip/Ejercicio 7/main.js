import { PalabraInvertida } from './Palabra.js';

let palabrasGuardadas = [];

document.getElementById('guardarButton').addEventListener('click', function () {
    const inputElement = document.getElementById('inputWord');
    const palabra = inputElement.value;

    if (/^[a-zA-Z]+$/.test(palabra.trim())) {
        palabrasGuardadas.push(palabra);
        inputElement.value = '';
        alert(`"${palabra}" Guardado con Éxito`);
    } else {
        alert('Por favor, ingrese solo letras y no números.');
    }
});

document.getElementById('validarButton').addEventListener('click', function () {
    const listaElement = document.getElementById('listaPalabras');
    listaElement.innerHTML = '';

    palabrasGuardadas.forEach(function (palabra) {
        const esPalindromo = verificarPalindromo(palabra);
        const listItem = document.createElement('li');
        
        if (esPalindromo) {
            listItem.textContent = `${palabra} es un palíndromo.`;
        } else {
            listItem.textContent = `${palabra} no es un palíndromo.`;
        }
        
        listaElement.appendChild(listItem);
    });
});

function verificarPalindromo(palabra) {
    const palabraLimpia = palabra.toLowerCase().replace(/[^a-z]/g, '');
    const palabraInvertida = PalabraInvertida.invertir(palabraLimpia);

    return palabraLimpia === palabraInvertida;
}


